process.env.NODE_ENV = 'test';

require('coffee-script');
require(__dirname + '/assert-extra');

